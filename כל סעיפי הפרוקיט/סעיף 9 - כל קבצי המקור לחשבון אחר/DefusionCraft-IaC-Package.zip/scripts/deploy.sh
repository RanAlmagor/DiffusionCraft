#!/bin/bash
################################################################################
# DefusionCraft – full IaC deploy                                             #
################################################################################

start_time=$(date +%s)

echo "🔍 Checking AWS CLI & permissions..."
aws sts get-caller-identity >/dev/null 2>&1 || {
  echo "❌ AWS CLI not configured properly. Aborting."
  exit 1
}

###############################################################################
# 1.  Lambda ZIPs → temp S3 bucket
###############################################################################
echo "🚀 Creating temporary S3 bucket for Lambda code..."
LAMBDA_BUCKET="defusioncraft-lambda-code-$(date +%s)"
aws s3 mb "s3://$LAMBDA_BUCKET"

echo "📦 Uploading Lambda ZIP files..."
LAMBDA_DIR="../lambda-code"
[ -d "$LAMBDA_DIR" ] || { echo "❌ Lambda code directory not found. Aborting."; exit 1; }

zip_count=0
for zip in "$LAMBDA_DIR"/*.zip; do
  [ -f "$zip" ] || continue
  aws s3 cp "$zip" "s3://$LAMBDA_BUCKET/$(basename "$zip")"
  echo "✅ Uploaded: $(basename "$zip")"
  ((zip_count++))
done

if [ "$zip_count" -eq 0 ]; then
  echo "⚠️ No ZIP files found in $LAMBDA_DIR"
  exit 1
fi

echo "⏱️  Lambda ZIP Upload Elapsed: $(( $(date +%s) - start_time )) s"

###############################################################################
# 2.  CloudFormation stacks (ordered)
###############################################################################
echo "📐 Deploying CloudFormation stacks..."
STACK_DIR="../cloudformation"
declare -A stacks=(
  [s3]="s3-buckets-full.yaml"
  [dynamodb]="dynamodb.yaml"
  [sqs]="sqs.yaml"
  [cognito]="cognito.yaml"
  [lambdas]="lambdas.yaml"
  [apigateway]="apigateway.yaml"
)

delete_if_rollback_complete () {
  local st_name="$1-stack"
  local status
  status=$(aws cloudformation describe-stacks --stack-name "$st_name" \
           --query "Stacks[0].StackStatus" --output text 2>/dev/null) || return
  if [[ "$status" == "ROLLBACK_COMPLETE" ]]; then
    echo "⚠️ $st_name is ROLLBACK_COMPLETE → deleting..."
    aws cloudformation delete-stack --stack-name "$st_name"
    aws cloudformation wait stack-delete-complete --stack-name "$st_name"
    echo "🗑️ Deleted $st_name"
  fi
}

for stk in s3 dynamodb sqs cognito lambdas apigateway; do
  tmpl="$STACK_DIR/${stacks[$stk]}"
  st_name="$stk-stack"
  [ -f "$tmpl" ] || { echo "❌ Missing template $tmpl"; exit 1; }

  delete_if_rollback_complete "$stk"

  echo "📤 Deploying $st_name ..."
  if [ "$stk" == "lambdas" ]; then
    aws cloudformation deploy \
      --stack-name "$st_name" \
      --template-file "$tmpl" \
      --capabilities CAPABILITY_NAMED_IAM \
      --parameter-overrides LambdaCodeBucket="$LAMBDA_BUCKET" || {
        echo "❌ Failed to deploy $st_name"; aws s3 rb "s3://$LAMBDA_BUCKET" --force; exit 1; }
  else
    aws cloudformation deploy \
      --stack-name "$st_name" \
      --template-file "$tmpl" \
      --capabilities CAPABILITY_NAMED_IAM || {
        echo "❌ Failed to deploy $st_name"; aws s3 rb "s3://$LAMBDA_BUCKET" --force; exit 1; }
  fi
done

###############################################################################
# 3.  Static website upload  (defusioncraft-static-<AccountId>)
###############################################################################
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
FRONTEND_BUCKET="defusioncraft-static-${ACCOUNT_ID}"
SITE_DIR="../DefusuonCraft_ClientSide"

echo "🌐 Uploading static site to ${FRONTEND_BUCKET}"

if ! aws s3 ls "s3://${FRONTEND_BUCKET}" >/dev/null 2>&1; then
  echo "🪣 Bucket missing → creating..."
  aws s3 mb "s3://${FRONTEND_BUCKET}"
  aws s3 website "s3://${FRONTEND_BUCKET}" \
     --index-document index.html --error-document error.html

  # ---------- Bucket Policy במקום ACL ----------
  cat > /tmp/public-read.json <<EOF
{
  "Version": "2012-10-17",
  "Statement": [{
    "Sid": "SiteRead",
    "Effect": "Allow",
    "Principal": "*",
    "Action": "s3:GetObject",
    "Resource": "arn:aws:s3:::${FRONTEND_BUCKET}/*"
  }]
}
EOF
  aws s3api put-bucket-policy \
      --bucket "${FRONTEND_BUCKET}" \
      --policy file:///tmp/public-read.json
fi

if [ -d "${SITE_DIR}" ]; then
  aws s3 sync "${SITE_DIR}/" "s3://${FRONTEND_BUCKET}/" --delete \
    --exclude ".git/*" --exclude "node_modules/*" --exclude ".vscode/*" \
    --exclude "ssl/*" --exclude "server.js"
  echo "✅ Static site uploaded."
else
  echo "⚠️ Site folder ${SITE_DIR} not found; skipping upload."
fi

###############################################################################
# 4.  Finish
###############################################################################
echo "🧹 Cleaning temp Lambda bucket ..."
aws s3 rb "s3://$LAMBDA_BUCKET" --force

echo "✅ Deployment complete in $(( $(date +%s) - start_time )) seconds."
exit 0
